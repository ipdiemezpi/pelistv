//= wrapped

//= require /systaro/core/systaro.core
//= require /streama/streama.translations

//= require_self

angular.module('streamaPublic', [
    'systaro.core',
    'streama.translations'
]);




